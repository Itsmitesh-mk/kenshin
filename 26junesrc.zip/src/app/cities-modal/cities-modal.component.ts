import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cities-modal',
  templateUrl: './cities-modal.component.html'
})
export class CitiesModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
