import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-apply-list',
  templateUrl: './leave-apply-list.component.html'
})
export class LeaveApplyListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
