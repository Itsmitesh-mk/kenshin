import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-apply-add',
  templateUrl: './leave-apply-add.component.html'
})
export class LeaveApplyAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
