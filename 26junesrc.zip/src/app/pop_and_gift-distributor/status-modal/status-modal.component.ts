import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-status-modal',
  templateUrl: './status-modal.component.html'
})
export class StatusModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
